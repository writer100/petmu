package com.practice2;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class BookManager {
	private ArrayList bookList;
	
	public BookManager() {
		bookList = new ArrayList();
	}
	
	public BookManager(ArrayList bookList) {
		this.bookList = bookList;
	}

	public void addBook(Book book) {	 //리스트에 객체 추가
		bookList.add(book);
	}
	
	public void deleteBook(int index) { //리스트에서 객체 제거
		bookList.remove(index);
	}
	
	public int searchBook(String bTitle) {
		//도서명이 일치하는 객체를 찾아 해당 인덱스를 리턴
		//도서명이 일치하는 객체가 리스트에 없으면, -1 리턴함
		int result = -1;
		
		for(int i = 0 ; i < bookList.size(); i++) {
			if(((Book)bookList.get(i)).getTitle().equals(bTitle)) {
				result = i;
				break;
			}
		}
		
		return result;
	}
	
	public void printBook(int index) { //인덱스 위치의 객체의 정보를 출력함
		
		System.out.println(bookList.get(index));
		
	}
	
	public void displayAll() {		//목록정보 모두 출력
		for(int i = 0; i < bookList.size(); i++) {
			System.out.println(bookList.get(i));
		}
	}
	
	public Book[] sortedBookList() {
		// 해당 카테고리순 오름차순정렬해서 객체배열 리턴함
		bookList.sort(new AscCategory());
		
		return (Book[]) bookList.toArray(new Book[bookList.size()]);
	}
	
	public void printBookList(Book[] br) {
		//객체 배열 출력, for-each 문 사용
		for(Book bk : br) {
			System.out.println(bk);
		}
	}

	public void saveBooks() {
		// 책 저장용 메소드
		try(ObjectOutputStream oo = new ObjectOutputStream(
				                     new FileOutputStream("books.dat"))){
			
			for(int i = 0 ; i < bookList.size(); i ++) {
				oo.writeObject(bookList.get(i));
			}
			
			System.out.println("파일 저장 완료!");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void loadBooks() {
		
		bookList.removeAll(bookList); //list 내용 전부 삭제
		
		try(ObjectInputStream oi = new ObjectInputStream(
									new FileInputStream("books.dat"))){
			
			Book bk = null;
			while((bk = (Book)oi.readObject()) != null) {
				bookList.add(bk);
			}
		} catch (EOFException e) {
			
			System.out.println("파일 읽기 완료!");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
}


