package com.practice2;


import java.util.Comparator;

public class DescCategory implements Comparator {

	@Override
	public int compare(Object bk1, Object bk2) {
		
		int result = ((Book)bk1).getCategory() >= ((Book)bk2).getCategory() ? 1 : -1;
	
		return result*-1;
	}

}
